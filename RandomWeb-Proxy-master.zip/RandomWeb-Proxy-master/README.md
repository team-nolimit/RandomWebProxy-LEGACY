# Archived!
I have decided to archive Rusty as it was made as a testing repo for corrosion. If you are using Rusty switch to [Shadow](https://github.com/FogNetwork/Shadow), another simple proxy site with corrosion

# Rusty
A simple frontend design for Corrosion you can deploy

<a href="https://heroku.com/deploy?template=https://github.com/FogNetwork/Rusty"><img height="30px" src="https://raw.githubusercontent.com/FogNetwork/Tsunami/main/deploy/heroku2.svg"><img></a>
<a href="https://repl.it/github/FogNetwork/Rusty"><img height="30px" src="https://raw.githubusercontent.com/FogNetwork/Tsunami/main/deploy/replit2.svg"><img></a>
<a href="https://glitch.com/edit/#!/import/github/FogNetwork/Rusty"><img height="30px" src="https://raw.githubusercontent.com/FogNetwork/Tsunami/main/deploy/glitch2.svg"><img></a>

Made using [Corrosion](https://github.com/titaniumnetwork-dev/Corrosion)
